Page({
data: { 
 catlist: [
{ name:"团团"},{ name:"圆圆"},{ name:"狲思藐"},{ name:"嘟嘟"},{ name:"荞麦"},{ name:"挠挠"},{ name:"骂骂"},{ name:"鲁班"},{ name:"大灰"},{ name:"小葱"},{ name:"皮蛋"},{ name:"酱油"},{ name:"对对"},{ name:"juju"},{ name:"小暹罗"},{ name:"咬咬"},{ name:"黄豆"},{ name:"花生"},{ name:"杨戬"},{ name:"蛋黄派"},{ name:"鼎橘"},{ name:"乘黄"},{ name:"瑞士卷"},{ name:"树橘"},{ name:"老君"},{ name:"脑袋哥"},{ name:"奥利奥"},{ name:"六六"},{ name:"警长"},{ name:"鳌拜"},{ name:"团子"},{ name:"大玳瑁"},{ name:"珊瑚"},{ name:"山药"},{ name:"肉段"},{ name:"云锦"},{ name:"奶黄包"},{ name:"奶茶"},{ name:"金银花"},{ name:"龙龙"},{ name:"琥珀"},{ name:"大白"},{ name:"煤球"},{ name:"豆腐"},{ name:"小黑"},
    ],
    screenWidth: 0,
    screenHeight: 0,
    imgwidth: 0,
    imgheight: 0
  },

  onPullDownRefresh:function(){
    wx.stopPullDownRefresh()
  },

  //转发跳转页面设置
  onLoad: function (options) {
    if (options.pageId) {
      
      wx.navigateTo({
        url: '/pages/cats/' + options.pageId + '/' + options.pageId,
      })
    }
  },

  //转发此页面的设置
  onShareAppMessage: function (ops) {
    if (ops.from === 'button') {
      // 来自页面内转发按钮
      console.log(ops.target)
    }
    return {
      path: 'pages/index/index',  // 路径，传递参数到指定页面。
      success: function (res) {
        // 转发成功
        console.log("转发成功:" + JSON.stringify(res));
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败:" + JSON.stringify(res));
      }
    }
  },

  // 搜索栏输入名字后页面跳转
  bindconfirmT: function (e) {
    console.log("e.detail.value");
    if(e.detail.value) {
    
    wx.navigateTo({
      url: '/pages/cats/' + e.detail.value + '/' + e.detail.value,
    })
  }
  }


})

